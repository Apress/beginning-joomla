<html>
<head>
	<jdoc:include type="head" />
</head>
<body>
	<jdoc:include type="message" />
	<div class="center" align="center">Hello World!</div>
	<jdoc:include type="modules" name="debug" />
</body>
</html>